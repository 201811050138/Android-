package cn.sdcet.android.news.domain;

import java.util.List;

public class CarouselData {
public int retcode;
public List<Carousel> carousels;

@Override
public String toString() {
	return "CarouselData [retcode=" + retcode + ", carousels=" + carousels
			+ "]";
}

public class Carousel {
	public String id;
	public String pubdate;
	public String title;
	public String image;
	public String url;
	@Override
	public String toString() {
		return "Carousel [id=" + id + ", pubdate=" + pubdate + ", title="
				+ title + ", image=" + image + ", url=" + url + "]";
	}
	
}
}
