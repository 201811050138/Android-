package cn.sdcet.android.news.domain;

import java.util.List;

public class NewsData {

	public int retcode;
	public String more;
	public List<News> news;
	
	@Override
	public String toString() {
		return "NewsData [retcode=" + retcode + ", more=" + more + ", news="
				+ news + "]";
	}

	public class News {
		public String id;
		public String image;
		public String pubdate;
		public String title;
		public String url;
		@Override
		public String toString() {
			return "News [id=" + id + ", image=" + image + ", pubdate="
					+ pubdate + ", title=" + title + ", url=" + url + "]";
		}
		
	}
}
