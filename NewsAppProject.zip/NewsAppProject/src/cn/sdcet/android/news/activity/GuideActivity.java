package cn.sdcet.android.news.activity;
import java.util.ArrayList;
import java.util.List;
import cn.sdcet.android.news.R;
import cn.sdcet.android.news.utils.Constants;
import cn.sdcet.android.news.base.BasePagerAdapter;
import cn.sdcet.android.news.utils.SharePreferencesUtils;
import com.lidroid.xutils.view.annotation.ViewInject;
import com.viewpagerindicator.CirclePageIndicator;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
//import android.provider.SyncStateContract.Constants;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;
public class GuideActivity extends Activity {
	private ViewPager vpGuide;
	private CirclePageIndicator indicator;

	private Button btnStart;

	private List<ImageView> imageList = new ArrayList<ImageView>();
	private int[] imageIds = new int[] { 
			R.drawable.guide_1,
			R.drawable.guide_2, R.drawable.guide_3 
			};	
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_guide);
       //ViewUtils.inject(this);����߼���idѰ�ҷ�������һ��
		vpGuide = (ViewPager) findViewById(R.id.vp_guide);
		indicator = (CirclePageIndicator) findViewById(R.id.cpi_guide);
		btnStart = (Button) findViewById(R.id.btnStart);
		initData();
	}
/**
 * 
 */
	private void initData() {
		for (int i = 0; i < imageIds.length; i++) {
			ImageView imageView = new ImageView(this);
			imageView.setBackgroundResource(imageIds[i]);
			imageList.add(imageView);
		}
		
		vpGuide.setAdapter(new BasePagerAdapter<ImageView>(imageList) {
			@Override
			public View getView(int position) {
				return imageList.get(position);
			}
		});
		indicator.setViewPager(vpGuide);
		indicator.setSnap(true);     //ʽ
		indicator.onPageSelected(0);//
		                           //
		indicator.setOnPageChangeListener(new OnPageChangeListener() {
			@Override
			public void onPageSelected(int position) {
				//
				if(position == imageList.size()- 1){
					btnStart.setVisibility(View.VISIBLE);
				} else {
					btnStart.setVisibility(View.GONE);
				}
			}
			@Override
			public void onPageScrolled(int arg0, float arg1, int arg2) {
			}
			
			@Override
			public void onPageScrollStateChanged(int arg0) {
			}
		});   
		btnStart.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				SharePreferencesUtils.putBoolean(getApplicationContext(), Constants.IS_GUIDE_SHOWN, true);
				Intent	intent = new Intent(getApplicationContext(),MainActivity.class);
				startActivity(intent);
				finish();
			}
		});
	}
}