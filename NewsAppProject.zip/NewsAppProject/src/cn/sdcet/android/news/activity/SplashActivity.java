package cn.sdcet.android.news.activity;

import cn.sdcet.android.news.R;
import cn.sdcet.android.news.R.layout;
import cn.sdcet.android.news.R.menu;
import cn.sdcet.android.news.utils.Constants;
import cn.sdcet.android.news.utils.SharePreferencesUtils;
import android.os.Bundle;
//import android.provider.SyncStateContract.Constants;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.sax.RootElement;
import android.view.Menu;
import android.view.Window;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationSet;
import android.view.animation.RotateAnimation;
import android.view.animation.ScaleAnimation;
import android.widget.RelativeLayout;

public class SplashActivity extends Activity {
	private RelativeLayout rootSplash;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_splash);
		rootSplash =  (RelativeLayout) findViewById(R.id.root_splash);
		//��ת
		RotateAnimation rotateAnimation = new RotateAnimation(0, 360,Animation.RELATIVE_TO_SELF,0.5f,Animation.RELATIVE_TO_SELF,0.5f);
		rotateAnimation.setDuration(1000);
		//�������յ� Ч��
		rotateAnimation.setFillAfter(true);
		//����
		ScaleAnimation scaleAnimation = new  ScaleAnimation(0,1,0,1,Animation.RELATIVE_TO_SELF,0.5f,Animation.RELATIVE_TO_SELF,0.5f);
		scaleAnimation.setDuration(1000);
		scaleAnimation.setFillAfter(true);
		//����
		AlphaAnimation alphaAnimation = new AlphaAnimation(0,1);
		alphaAnimation.setDuration(2000);
	    alphaAnimation.setFillAfter(true);
	    
	    //�����ϼ�
	    AnimationSet animationSet = new AnimationSet(false);
	    animationSet.addAnimation(rotateAnimation);
	    animationSet.addAnimation(scaleAnimation);
	    animationSet.addAnimation(alphaAnimation);
	    animationSet.setAnimationListener(new AnimationListener() {
			
			@Override
			public void onAnimationStart(Animation animation) {
				
			}
			
			@Override
			public void onAnimationRepeat(Animation animation) {
				
			}
			
			@Override
			public void onAnimationEnd(Animation animation) {
				//��������ʱ 
			boolean isGuideShown = SharePreferencesUtils.getBoolean(getApplicationContext(), Constants.IS_GUIDE_SHOWN, false);
			if(isGuideShown) {
				//�Ѿ���ʾ��
				Intent	intent = new Intent(getApplicationContext(),MainActivity.class);
				startActivity(intent);
			}
			else {
				//�û��״�
			    Intent	intent = new Intent(getApplicationContext(),GuideActivity.class);
			    startActivity(intent);
			}
			
				finish();
			}
		});
	    //��������
	    rootSplash.startAnimation(animationSet);
	}
}
