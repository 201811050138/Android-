package cn.sdcet.android.news.activity;

import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.view.annotation.ViewInject;

import cn.sdcet.android.news.R;
import cn.sdcet.android.news.R.layout;
import cn.sdcet.android.news.R.menu;
import cn.sdcet.android.news.utils.Constants;
import android.os.Bundle;
import android.app.Activity;
import android.graphics.Bitmap;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageButton;
import android.widget.ProgressBar;

public class ShowNewsActivity extends Activity {
	@ViewInject(R.id.btn_show_news_back)
	private ImageButton btnBack;
	@ViewInject(R.id.btn_show_news_share)
	private ImageButton btnShare;
	@ViewInject(R.id.wv_show_news)
	private WebView webView;
	@ViewInject(R.id.pb_show_news_loading)
	private ProgressBar progress;

	private String url;
	private String title;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_show_news);

		ViewUtils.inject(this);

		initWebView();
		btnBack.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				ShowNewsActivity.this.finish();
			}
		});

	}

	private void initWebView() {
		WebSettings settings = webView.getSettings();
		settings.setJavaScriptEnabled(true);
		settings.setBuiltInZoomControls(false);
		settings.setUseWideViewPort(true);

		webView.setWebViewClient(new WebViewClient() {
			@Override
			public boolean shouldOverrideUrlLoading(WebView view, String url) {
				webView.loadUrl(url);
				return true;
			}

			@Override
			public void onPageStarted(WebView view, String url, Bitmap favicon) {

				super.onPageStarted(view, url, favicon);
				progress.setVisibility(View.VISIBLE);
			}

			@Override
			public void onPageFinished(WebView view, String url) {
				super.onPageFinished(view, url);
				progress.setVisibility(View.GONE);
			}
		});

		webView.setWebChromeClient(new WebChromeClient() {
			@Override
			public void onProgressChanged(WebView view, int newProgress) {
				super.onProgressChanged(view, newProgress);
			}

			@Override
			public void onReceivedTitle(WebView view, String title) {
				super.onReceivedTitle(view, title);
			}
		});
		url = getIntent().getStringExtra("url");
		title = getIntent().getStringExtra("url");
		webView.loadUrl(Constants.SERVER_URL + "/" + url);
	}
	@Override
	public void onBackPressed() {
	 if(webView.canGoBack()) {
		 webView.goBack();
		 
	 }else {
		 finish();
		 
	 }
	}

}
