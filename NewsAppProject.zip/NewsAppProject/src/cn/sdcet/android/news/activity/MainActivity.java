package cn.sdcet.android.news.activity;

import java.nio.channels.AlreadyConnectedException;
import java.util.ArrayList;
import java.util.List;

import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.view.annotation.ViewInject;

import cn.sdcet.android.news.R;
import cn.sdcet.android.news.R.layout;
import cn.sdcet.android.news.R.menu;
import cn.sdcet.android.news.base.BasePage;
import cn.sdcet.android.news.page.HomePage;
import cn.sdcet.android.news.page.SettingsPage;
import cn.sdcet.android.news.page.VideoPage;
import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.view.Menu;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;

public class MainActivity extends Activity {
	@ViewInject(R.id.rg_tab_group)
	private RadioGroup tabGroup;
	@ViewInject(R.id.fl_content)
	private FrameLayout flContent;
	
    private List<BasePage> mPages;
    
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_main);

		ViewUtils.inject(this);
		initData();
	}

	private void initData() {
		mPages = new ArrayList<BasePage>();
		mPages.add(new HomePage(this));
		mPages.add(new VideoPage(this));
		mPages.add(new SettingsPage(this));
		tabGroup.setOnCheckedChangeListener(new OnCheckedChangeListener() {

			@Override
			public void onCheckedChanged(RadioGroup group, int checkedId) {
				BasePage  page = null;
				switch (checkedId) {
				case R.id.rb_tab_home:
					page = mPages.get(0);
				break;
				
				case R.id.rb_tab_activity:
					page = mPages.get(1);
				break;
				
				case R.id.rb_tab_setting:
					page = mPages.get(2);
				break;
				}
				flContent.removeAllViews();
				flContent.addView(page.mRootView);
		//chushihuaPage
				page.initData();
			}
		});
		//shoudongchushihuaPage
		BasePage page = mPages.get(0);
		flContent.addView(page.mRootView);
		page.initData();
	}

	@Override
	public void onBackPressed() {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle("提示消息");
		builder.setMessage("确定退出应用吗？");
		builder.setNegativeButton("取消", null);
		builder.setPositiveButton("确定", new OnClickListener() {

			@Override
			public void onClick(DialogInterface dialog, int which) {

				finish();
			}
		});
		AlertDialog dialog = builder.create();
		dialog.show();

	}
}