package cn.sdcet.android.news.utils;

public class Constants {
public static final String TAG = "cn.sdcet.android.news";
	public static final String IS_GUIDE_SHOWN = "is_guide_shown";
	public static final String SERVER_URL = "http://192.168.43.103:8080/news";
	public static final String NEWS_URL = SERVER_URL + "/list.json";
	public static final String CAROUSEL_URL = SERVER_URL + "/carousel.json";

}