package cn.sdcet.android.news.utils;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import android.content.Context;

/**
 * 数据缓存工具类
 */
public class CacheUtils {

	/**
	 * 读取缓存数据，以URL的MD5加密值为文件名。
	 * 如果缓存文件不存在，返回空字符串。
	 */
	public static String get(Context ctx, String url) {
		String fileName = MD5Utils.encode(url);
		String result = "";
		
		try {
			FileInputStream fis = ctx.openFileInput(fileName);
			byte[] buffer = new byte[fis.available()];
			fis.read(buffer);
			fis.close();
			
			result = new String(buffer);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return result;
	}
	
	/**
	 * 写缓存数据，以URL的MD5加密值为文件名
	 */
	public static void set(Context ctx, String url, String content) {
		String fileName = MD5Utils.encode(url);
		
		try {
			FileOutputStream fos = ctx.openFileOutput(fileName, Context.MODE_PRIVATE);
			fos.write(content.getBytes());
			fos.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
