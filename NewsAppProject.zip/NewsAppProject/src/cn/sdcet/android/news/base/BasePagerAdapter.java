package cn.sdcet.android.news.base;

import java.util.List;

import android.support.v4.view.PagerAdapter;
import android.view.View;
import android.view.ViewGroup;

/**
 * PagerAdapter����
 */
public abstract class BasePagerAdapter<T> extends PagerAdapter {
	private List<T> mList;
	
	public BasePagerAdapter(List<T> mList) {
		this.mList = mList;
	}
	
	@Override
	public int getCount() {
		return mList.size();
	}

	@Override
	public boolean isViewFromObject(View view, Object object) {
		return object == view;
	}
	
	@Override
	public void destroyItem(ViewGroup container, int position, Object object) {
		container.removeView((View) object);
	}
	
	@Override
	public Object instantiateItem(ViewGroup container, int position) {
		View view = getView(position);
		container.addView(view);
		return view;
	}
	
	/**
	 * ��ȡָ��λ���ϵ���ͼ���
	 */
	public abstract View getView(int position);
}
