package cn.sdcet.android.news.page;

import android.app.Activity;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.TextView;
import cn.sdcet.android.news.base.BasePage;

public class SettingsPage extends BasePage {

	public SettingsPage(Activity mActivity) {
		super(mActivity);
	}
@Override
public void initData() {
     TextView view = new TextView(mActivity);
     view.setText("我的");
     view.setTextColor(Color.RED);
     view.setTextSize(22);
     view.setGravity(Gravity.CENTER);
     
     tabPageContent.addView(view);
     tvTitle.setText("设置页面");
}
}
