package cn.sdcet.android.news.page;

import android.app.Activity;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.TextView;
import cn.sdcet.android.news.base.BasePage;

public class VideoPage extends BasePage {

	public VideoPage(Activity mActivity) {
		super(mActivity);
	}
@Override
public void initData() {
     TextView view = new TextView(mActivity);
     view.setText("精彩视频");
     view.setTextColor(Color.RED);
     view.setTextSize(22);
     view.setGravity(Gravity.CENTER);
     
     tabPageContent.addView(view);
     tvTitle.setText("视频页面");
}
}
