package cn.sdcet.android.news.page;

import java.lang.annotation.Annotation;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.google.gson.Gson;
import com.lidroid.xutils.BitmapUtils;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.lidroid.xutils.view.annotation.ViewInject;
import com.lidroid.xutils.view.annotation.event.OnClick;
import com.markmao.pulltorefresh.widget.XListView;
import com.markmao.pulltorefresh.widget.XListView.IXListViewListener;
import com.viewpagerindicator.CirclePageIndicator;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Handler;
import android.os.Message;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.test.IsolatedContext;
import android.text.GetChars;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.TextView;
import android.widget.Toast;
import cn.sdcet.android.news.R;
import cn.sdcet.android.news.activity.ShowNewsActivity;
import cn.sdcet.android.news.base.BasePage;
import cn.sdcet.android.news.base.BasePagerAdapter;
import cn.sdcet.android.news.domain.CarouselData;
import cn.sdcet.android.news.domain.CarouselData.Carousel;
import cn.sdcet.android.news.domain.NewsData;
import cn.sdcet.android.news.domain.NewsData.News;
import cn.sdcet.android.news.utils.CacheUtils;
import cn.sdcet.android.news.utils.Constants;

public class HomePage extends BasePage implements IXListViewListener {
	@ViewInject(R.id.vp_carousel)
	private ViewPager vpCarousel;
	@ViewInject(R.id.cpi_carousel)
	private CirclePageIndicator indicator;
	@ViewInject(R.id.tv_carousel)
	private TextView tvDescription;
	@ViewInject(R.id.list_view)
	private XListView lvList;

	private SimpleDateFormat sdf;

	private List<News> newsData;
	private NewsAdapter adapter;
    
	private BitmapUtils bitmapUtils;
	
	private Handler handler;
	
	private String moreUrl;
	public HomePage(Activity mActivity) {
		super(mActivity);
		bitmapUtils = new BitmapUtils(mActivity);
		//设置加载中的图片
		bitmapUtils.configDefaultLoadingImage(R.drawable.news_image_default);
		
	}

	@Override
	public void initData() {
		tvTitle.setText("新闻中心");
		
		initList();
		
		//处理轮播图数据
		String carouselCache = CacheUtils.get(mActivity, Constants.CAROUSEL_URL);
		if(!TextUtils.isEmpty(carouselCache)) {
			processCarouselData(carouselCache);
			
		}
		getCarouselDataFormServer();
		
		//处理新闻数据
		String newsCache = CacheUtils.get(mActivity, Constants.NEWS_URL);
		if(!TextUtils.isEmpty(newsCache)) {
			//或许也要改撒
			processNewsData(carouselCache,false);
			
		}
		getNewsDataFromServer(Constants.NEWS_URL,false);
		
        }
/**
 * 从服务器段读取新闻数据
 * @param isLoadingMore是哦福是加载更多
 */
    private void getNewsDataFromServer(String url, final boolean isLoadingMore) {
    	HttpUtils utils = new HttpUtils();
	    utils.send(HttpMethod.GET,url,new RequestCallBack<String>() {
			@Override
			public void onFailure(HttpException error, String message) {
				error.printStackTrace();
				Toast.makeText(mActivity, "获取新闻数据失败"+ message,Toast.LENGTH_SHORT).show();
				
			}

			@Override
			public void onSuccess(ResponseInfo<String> responseInfo) {	
				String result = responseInfo.result;
				Log.d(Constants.TAG,"获取新闻数据" + result);
				//缓存服务器设被，加载更多数据不需要缓存
				if(!isLoadingMore) {
					CacheUtils.set(mActivity, Constants.NEWS_URL,result);//或许
				}
				
				processNewsData(result,isLoadingMore);
			}
		});	
	}
    
	private void processNewsData(String result, boolean isLoadingMore) {
		Gson gson = new Gson();
		final NewsData data = gson.fromJson(result,NewsData.class);	
		moreUrl = data.more;
		if(data.news != null) {
			if(!isLoadingMore) {
	          newsData = data.news;
	          adapter = new NewsAdapter();
	          lvList.setAdapter(adapter);
			}else{
	          //加载更多，最佳数据
				newsData.addAll(data.news);
				adapter.notifyDataSetChanged();
			}
			
		}
	}
	
	
	private void getCarouselDataFormServer() {
		HttpUtils utils = new HttpUtils();
	    utils.send(HttpMethod.GET,Constants.CAROUSEL_URL,new RequestCallBack<String>() {

			@Override
			public void onFailure(HttpException error, String message) {
				error.printStackTrace();
				Toast.makeText(mActivity, "获取轮播图数据失败"+ message,Toast.LENGTH_SHORT).show();
				
			}

			@Override
			public void onSuccess(ResponseInfo<String> responseInfo) {	
				String result = responseInfo.result;
				Log.d(Constants.TAG,"获取轮播图数据成功" + result);
				//��������� 
				CacheUtils.set(mActivity, Constants.CAROUSEL_URL,result);
				processCarouselData(result);
			}
		});
	}
	/**
	 * 解析轮播图
	 */
	private void processCarouselData(String result) {	
		 Gson gson = new Gson();
		 final CarouselData data = gson.fromJson(result,CarouselData.class);
		Log.d(Constants.TAG,data.toString());
		
		if(data.carousels !=  null) {
			vpCarousel.setAdapter(new BasePagerAdapter<Carousel>(data.carousels) {

				@Override
				public View getView(int position) {
					ImageView  imageView = new ImageView(mActivity);
//缩放，匹配窗体
					imageView.setScaleType(ScaleType.FIT_XY);
					String path =  Constants.SERVER_URL + "/"  + data.carousels.get(position).image;
					bitmapUtils.display(imageView, path);
					return imageView;
				}
			});
			
			indicator.setViewPager(vpCarousel);
			indicator.setSnap(true);
			indicator.onPageSelected(0);
			//切换时更新 轮播图的标题
			indicator.setOnPageChangeListener(new OnPageChangeListener() {
				
				@Override
				public void onPageSelected(int position) {
					tvDescription.setText(data.carousels.get(position).title);
				}
				
				@Override
				public void onPageScrolled(int arg0, float arg1, int arg2) {
					
				}
				
				@Override
				public void onPageScrollStateChanged(int arg0) {
					
				}
			});
			//或许魅有这一行
			tvDescription.setText(data.carousels.get(0).title);
			if(handler == null)  {
				handler = new Handler(){
					@Override
					public void handleMessage(Message msg) {
						int pos = vpCarousel.getCurrentItem();
						pos = ++pos % data.carousels.size();
						vpCarousel.setCurrentItem(pos);
				
						handler.sendEmptyMessageDelayed(0, 3000);
					}
				};
				handler.sendEmptyMessageDelayed(0, 3000);
			}
		}
	}

	private void initList() {
		View view = View.inflate(mActivity, R.layout.page_home, null);
		View headerView = View.inflate(mActivity, R.layout.page_home_header,null);
		ViewUtils.inject(this,view);
		ViewUtils.inject(this,headerView);
		
		sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		
	    lvList.addHeaderView(headerView);
		lvList.setPullRefreshEnable(true);
		lvList.setPullLoadEnable(true);
		lvList.setAutoLoadEnable(true);
		lvList.setXListViewListener(this);
		lvList.setRefreshTime(getTime());
		lvList.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position,
					long id) {
				//头布局也占位置
				int headCount = lvList.getHeaderViewsCount();
				News news =newsData.get(position - headCount);
				
				Intent intent = new Intent(mActivity,ShowNewsActivity.class);
				intent.putExtra("title",news.title);
				intent.putExtra("url",news.url);
				mActivity.startActivity(intent);
				
				
			}
		});
        tabPageContent.removeAllViews();
        tabPageContent.addView(view);
	}
	
	private String getTime() {
		return sdf.format(new Date());
	}


	@Override
	public void onRefresh() {
	 getNewsDataFromServer(Constants.NEWS_URL,false);
	
	 lvList.stopRefresh();
	 lvList.stopLoadMore();
	 lvList.setRefreshTime(getTime());
	}

	@Override
	public void onLoadMore(){
	  if(TextUtils.isEmpty(moreUrl)) {
		  //没有更多数据了
		  Toast.makeText(mActivity, "no data", Toast.LENGTH_SHORT).show();
	  }else {
		  String url = Constants.SERVER_URL  + "/" +moreUrl;
		  getNewsDataFromServer(url,true);
	  }
		  
	  lvList.stopRefresh();
	  lvList.stopLoadMore();
	  lvList.setRefreshTime(getTime());

	}
	
	class ViewHolder {
		public ImageView iv_icon;
		public TextView tv_title;
		public TextView tv_time;
	}
	
	class NewsAdapter extends BaseAdapter {

		@Override
		public int getCount() {
			return newsData.size();
		}

		@Override
		public News getItem(int position) {
			return newsData.get(position);
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			ViewHolder  holder;
			if(convertView == null)  {
				convertView = View.inflate(mActivity, R.layout.vw_list_item,null);
				holder = new ViewHolder();
				holder.iv_icon = (ImageView) convertView.findViewById(R.id.iv_news_icon);
				holder.tv_title = (TextView) convertView.findViewById(R.id.tv_news_title);
				holder.tv_time = (TextView) convertView.findViewById(R.id.tv_news_time);
				
				convertView.setTag(holder);
			}
			else {
				holder = (ViewHolder) convertView.getTag();
			}
			News news = getItem(position);
			holder.tv_title.setText(news.title);
			holder.tv_time.setText(news.pubdate);
			bitmapUtils.display(holder.iv_icon,Constants.SERVER_URL + "/" +news.image);
			
			return convertView;
		}
		
	}
}
