/** Automatically generated file. DO NOT MODIFY */
package cn.sdcet.android.news;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}